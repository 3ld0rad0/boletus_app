import { useEffect, useMemo, useState } from "react"

type IconName = "search" | "user" | "info" | "locate" | "close" | "chevron" | "flag" | "layers" | "moon" | "sun" | "eye" | "more" | "check" | "warning" | "arrow"

function Icon({ name, size = 22 }: { name: IconName size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    user: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4.8 20c.8-4 3.2-6 7.2-6s6.4 2 7.2 6" />
      </>
    ),
    info: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 11v6M12 7h.01" />
      </>
    ),
    locate: (
      <>
        <circle cx="12" cy="12" r="5" />
        <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
      </>
    ),
    close: <path d="m6 6 12 12M18 6 6 18" />,
    chevron: <path d="m7 10 5 5 5-5" />,
    flag: (
      <>
        <path d="M6 21V4" />
        <path d="M6 5c4-3 7 3 12 0v9c-5 3-8-3-12 0" />
      </>
    ),
    layers: (
      <>
        <path d="m12 3 9 5-9 5-9-5 9-5Z" />
        <path d="m3 12 9 5 9-5M3 16l9 5 9-5" />
      </>
    ),
    moon: <path d="M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5Z" />,
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
      </>
    ),
    eye: (
      <>
        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" />
        <circle cx="12" cy="12" r="2.5" />
      </>
    ),
    more: (
      <>
        <circle cx="5" cy="12" r="1" fill="currentColor" />
        <circle cx="12" cy="12" r="1" fill="currentColor" />
        <circle cx="19" cy="12" r="1" fill="currentColor" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    warning: (
      <>
        <path d="M12 3 2.8 20h18.4L12 3Z" />
        <path d="M12 9v4M12 17h.01" />
      </>
    ),
    arrow: (
      <>
        <path d="M12 21V4" />
        <path d="m5 11 7-7 7 7" />
      </>
    ),
  }
  return (
    <svg
      className="icon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

const species = [
  ["Porcino", "Boletus edulis"],
  ["Finferlo", "Cantharellus cibarius"],
  ["Mazza di tamburo", "Macrolepiota procera"],
  ["Ovolo", "Amanita caesarea"],
  ["Prugnolo", "Calocybe gambosa"],
  ["Rosito", "Lactarius deliciosus"],
  ["Spugnola", "Morchella esculenta"],
  ["Chiodino", "Armillaria mellea"],
]

const bands = [
  { key: "veryLow", label: "Molto bassa", color: "#8e1b1b", range: "< 17" },
  { key: "low", label: "Bassa", color: "#d64933", range: "17–32" },
  { key: "mediumLow", label: "Medio-bassa", color: "#f08a24", range: "33–49" },
  { key: "mediumHigh", label: "Medio-alta", color: "#f2c334", range: "50–65" },
  { key: "high", label: "Alta", color: "#9ccc3c", range: "66–82" },
  { key: "veryHigh", label: "Molto alta", color: "#1b7a3a", range: "≥ 83" },
]

const factors = [
  [
    "Stagione",
    "moltiplicatore",
    "ottimale",
    92,
    "Ottobre, nel periodo ottimale set–nov",
  ],
  [
    "Quota",
    "moltiplicatore",
    "ottimale",
    86,
    "Quota 850 m, fascia ottimale 600–1.200 m",
  ],
  ["Temperatura", "", "accettabile", 68, "14 °C, ideale tra 12 °C e 18 °C"],
  ["Pioggia", "", "ottimale", 88, "42 mm accumulati negli ultimi 10 giorni"],
  ["Umidità", "", "accettabile", 74, "Umidità del suolo stimata al 71%"],
  [
    "Vegetazione",
    "",
    "scarso",
    38,
    "Copertura compatibile rilevata parzialmente",
  ],
]

function polar(cx: number, cy: number, r: number, angle: number) {
  const a = ((angle - 90) * Math.PI) / 180
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) }
}

function wedge(inner: number, outer: number, start: number, end: number) {
  const a = polar(195, 365, outer, end)
  const b = polar(195, 365, outer, start)
  const c = polar(195, 365, inner, start)
  const d = polar(195, 365, inner, end)
  return `M ${a.x} ${a.y} A ${outer} ${outer} 0 0 0 ${b.x} ${b.y} L ${c.x} ${c.y} A ${inner} ${inner} 0 0 1 ${d.x} ${d.y} Z`
}

function TopographicMap({
  grid,
  onCell,
}: {
  grid: boolean
  onCell: () => void
}) {
  const cells = useMemo(
    () =>
      Array.from({ length: 40 }, (_, i) => {
        const ring = Math.floor(i / 8)
        const band = bands[(i * 5 + ring * 2) % bands.length]
        return {
          path: wedge(
            28 + ring * 32,
            60 + ring * 32,
            (i % 8) * 45,
            ((i % 8) + 1) * 45,
          ),
          band,
        }
      }),
    [],
  )

  return (
    <div className="map" aria-label="Mappa topografica dell'area">
      <svg
        className="topo"
        viewBox="0 0 390 844"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
      >
        <defs>
          <filter id="soft">
            <feGaussianBlur stdDeviation="12" />
          </filter>
          <pattern
            id="gridlines"
            width="36"
            height="36"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M36 0H0V36"
              fill="none"
              stroke="var(--map-grid)"
              strokeWidth=".6"
            />
          </pattern>
        </defs>
        <rect width="390" height="844" fill="var(--map-base)" />
        <path
          className="forest"
          d="M-40 110C60 35 118 170 215 98S354 52 440 116v225c-120 75-160-35-275 25S12 380-40 448Z"
        />
        <path
          className="meadow"
          d="M-35 555c80-96 156-26 220-90s158-84 255-20v399H-35Z"
        />
        <g className="contours">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <path
              key={i}
              d={`M-30 ${90 + i * 116} C 75 ${10 + i * 125}, 135 ${180 + i * 95}, 235 ${95 + i * 117} S 350 ${180 + i * 105}, 430 ${105 + i * 115}`}
            />
          ))}
          <path d="M-40 250c85-80 145 40 212-15s147-54 250 10" />
          <path d="M-20 665c95-100 140 28 215-30s135-43 230 20" />
          <ellipse cx="78" cy="476" rx="58" ry="28" />
          <ellipse cx="78" cy="476" rx="42" ry="19" />
        </g>
        <path
          className="trail"
          d="M-20 722C82 650 92 506 183 445s84-194 230-236"
        />
        <path
          className="stream"
          d="M335-10c-58 110 28 188-40 277s-28 169-92 249-23 188-86 340"
        />
        <rect width="390" height="844" fill="url(#gridlines)" opacity=".32" />
        {grid && (
          <g className="probability-grid">
            {cells.map((cell, i) => (
              <path
                key={i}
                d={cell.path}
                fill={cell.band.color}
                onClick={onCell}
                tabIndex={0}
                role="button"
                aria-label={`Cella: probabilità ${cell.band.label}`}
              />
            ))}
          </g>
        )}
      </svg>
      <div className="map-label label-a">
        Monte Cocuzzo <small>1.541 m</small>
      </div>
      <div className="map-label label-b">Sentiero 422</div>
      <div className="start-marker" aria-label="Punto di partenza">
        <Icon name="flag" size={20} />
      </div>
      <div className="accuracy">
        <div className="gps-dot" />
      </div>
      <div className="scale">250 m</div>
    </div>
  )
}

function PointSection({
  state,
  onSave,
  onArrive,
  onConfirm,
}: {
  state: "none" | "saved" | "arrived" | "unavailable"
  onSave: () => void
  onArrive: () => void
  onConfirm: (kind: "replace" | "delete") => void
}) {
  if (state === "none")
    return (
      <section className="point compact-section">
        <div>
          <h3>Punto di partenza</h3>
          <p>Salva la posizione per ritrovare la strada.</p>
        </div>
        <button className="button primary" onClick={onSave}>
          <Icon name="flag" /> Salva punto di partenza
        </button>
      </section>
    )
  if (state === "unavailable")
    return (
      <section className="point error-point">
        <h3>Punto di partenza</h3>
        <p>
          <Icon name="warning" /> Posizione attuale non disponibile
        </p>
        <button className="button secondary" onClick={onSave}>
          Riprova
        </button>
      </section>
    )
  if (state === "arrived")
    return (
      <section className="point arrived">
        <div className="arrived-icon">
          <Icon name="check" size={30} />
        </div>
        <div>
          <p className="eyebrow">Punto di partenza</p>
          <h3>Sei al punto di partenza</h3>
          <p>Precisione GPS ±12 m</p>
        </div>
        <button className="text-button" onClick={() => onConfirm("delete")}>
          Elimina
        </button>
      </section>
    )
  return (
    <section className="point saved">
      <div className="direction">
        <div className="direction-arrow">
          <Icon name="arrow" size={43} />
        </div>
        <span>NE</span>
      </div>
      <div className="distance">
        <p className="eyebrow">Punto di partenza</p>
        <strong>850 m</strong>
        <span>verso NE (45°)</span>
        <small>Precisione ±12 m · salvato alle 08:42</small>
      </div>
      <div className="point-actions">
        <button onClick={() => onConfirm("replace")}>Sostituisci</button>
        <button onClick={() => onConfirm("delete")}>Elimina</button>
        <button className="arrival-demo" onClick={onArrive}>
          Segna arrivo
        </button>
      </div>
    </section>
  )
}

function CellDetail({
  speciesName,
  onClose,
}: {
  speciesName: string
  onClose: () => void
}) {
  return (
    <div
      className="detail-sheet"
      role="dialog"
      aria-label="Dettaglio probabilità"
    >
      <div className="sheet-handle" />
      <div className="detail-head">
        <div>
          <p className="eyebrow">Dettaglio della cella</p>
          <h2>
            {speciesName}: <span>72/100</span>
          </h2>
          <span className="probability-badge">Probabilità alta</span>
        </div>
        <button
          className="icon-button"
          onClick={onClose}
          aria-label="Chiudi dettaglio"
        >
          <Icon name="close" />
        </button>
      </div>
      <p className="detail-note">
        Stagione e quota abbassano il punteggio in modo graduale, senza
        azzerarlo.
      </p>
      <div className="factors">
        {factors.map(([name, tag, verdict, value, detail]) => (
          <div className="factor" key={name}>
            <div className="factor-head">
              <strong>{name}</strong>
              {tag && <span className="mini-tag">{tag}</span>}
              <span className={`verdict ${verdict}`}>{verdict}</span>
            </div>
            <div className="progress" aria-label={`${name}: ${value}%`}>
              <span style={{ width: `${value}%` }} />
            </div>
            <p>{detail}</p>
          </div>
        ))}
      </div>
      <div className="forest-estimate">
        <strong>Bosco probabile:</strong> faggeta{" "}
        <span>
          Stima disponibile per la Calabria; può differire dalla vegetazione
          reale.
        </span>
      </div>
      <p className="sources">
        Fonti dati: Open-Meteo, Copernicus DEM, Corine Land Cover ·
        Aggiornamento meteo 18 min fa
      </p>
    </div>
  )
}

function AccountPanel({
  onClose,
  dark,
  setDark,
}: {
  onClose: () => void
  dark: boolean
  setDark: (v: boolean) => void
}) {
  const [tab, setTab] = useState<"login" | "register">("login")
  const [logged, setLogged] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  return (
    <div className="full-panel" role="dialog" aria-label="Account">
      <header className="panel-header">
        <div>
          <p className="eyebrow">Profilo</p>
          <h2>Il tuo account</h2>
        </div>
        <button className="icon-button" onClick={onClose} aria-label="Chiudi">
          <Icon name="close" />
        </button>
      </header>
      <button className="theme-row" onClick={() => setDark(!dark)}>
        <span>
          <Icon name={dark ? "sun" : "moon"} /> Tema {dark ? "chiaro" : "scuro"}
        </span>
        <span className={`switch ${dark ? "on" : ""}`} />
      </button>
      {!logged ? (
        <>
          <p className="panel-intro">
            Accedi per salvare i tuoi punti sul server. L’app funziona anche
            senza account.
          </p>
          <div className="tabs">
            <button
              className={tab === "login" ? "active" : ""}
              onClick={() => setTab("login")}
            >
              Accedi
            </button>
            <button
              className={tab === "register" ? "active" : ""}
              onClick={() => setTab("register")}
            >
              Registrati
            </button>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              setLogged(true)
            }}
          >
            <label>
              Email
              <input type="email" placeholder="nome@esempio.it" required />
            </label>
            <label>
              Password{" "}
              <span className="input-wrap">
                <input
                  type={showPassword ? "text" : "password"}
                  minLength={8}
                  placeholder="Almeno 8 caratteri"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label="Mostra password"
                >
                  <Icon name="eye" />
                </button>
              </span>
            </label>
            {tab === "register" && (
              <p className="field-help">Usa almeno 8 caratteri.</p>
            )}
            <button className="button primary" type="submit">
              {tab === "login" ? "Accedi" : "Crea account"}
            </button>
          </form>
        </>
      ) : (
        <>
          <div className="logged-card">
            <div className="avatar">MB</div>
            <div>
              <strong>mario.bianchi@email.it</strong>
              <span>Account attivo</span>
            </div>
            <button className="text-button" onClick={() => setLogged(false)}>
              Esci
            </button>
          </div>
          <div className="saved-title">
            <h3>Punti salvati</h3>
            <span>2 punti</span>
          </div>
          {[
            ["Parcheggio Faggio", "39.2314, 16.1648"],
            ["Rifugio Piano Lago", "39.2461, 16.1820"],
          ].map((p) => (
            <div className="saved-place" key={p[0]}>
              <span className="place-icon">
                <Icon name="flag" />
              </span>
              <div>
                <strong>{p[0]}</strong>
                <small>{p[1]}</small>
                <button>Usa come partenza</button>
              </div>
              <button className="icon-button" aria-label="Altre azioni">
                <Icon name="more" />
              </button>
            </div>
          ))}
        </>
      )}
    </div>
  )
}

function Notice({ onClose }: { onClose: () => void }) {
  return (
    <div className="modal-layer">
      <div
        className="notice-modal"
        role="alertdialog"
        aria-labelledby="notice-title"
      >
        <div className="notice-mark">
          <Icon name="warning" size={30} />
        </div>
        <p className="eyebrow">Prima di iniziare</p>
        <h2 id="notice-title">Cerca in sicurezza</h2>
        <p>
          Boletus indica solo <strong>dove</strong> potrebbe valere la pena
          cercare. Non identifica i funghi e non ne garantisce la
          commestibilità: fai sempre controllare il raccolto da un micologo o
          dall'ispettorato micologico della ASL e rispetta le norme locali sulla
          raccolta.
        </p>
        <button className="button primary" onClick={onClose}>
          Ho capito
        </button>
      </div>
    </div>
  )
}

export default function App() {
  const [notice, setNotice] = useState(true)
  const [account, setAccount] = useState(false)
  const [dark, setDark] = useState(false)
  const [search, setSearch] = useState("")
  const [searchOpen, setSearchOpen] = useState(false)
  const [selectedSpecies, setSelectedSpecies] = useState(0)
  const [grid, setGrid] = useState(false)
  const [loading, setLoading] = useState<0 | 1 | 2>(0)
  const [detail, setDetail] = useState(false)
  const [sheet, setSheet] = useState<"partial" | "expanded">("partial")
  const [point, setPoint] =
    useState<"none" | "saved" | "arrived" | "unavailable">("none")
  const [confirm, setConfirm] = useState<"replace" | "delete" | null>(null)
  const [legend, setLegend] = useState(false)
  const [offline, setOffline] = useState(false)
  const [banner, setBanner] = useState<"vegetation" | "gps" | null>(null)

  const calculate = () => {
    if (offline) {
      setBanner("vegetation")
      setGrid(true)
      return
    }
    setLoading(1)
    window.setTimeout(() => setLoading(2), 900)
    window.setTimeout(() => {
      setLoading(0)
      setGrid(true)
      setBanner("vegetation")
    }, 1800)
  }
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light"
  }, [dark])

  return (
    <main className="app-shell">
      <TopographicMap grid={grid} onCell={() => grid && setDetail(true)} />

      <header className="top-controls">
        <div className="top-line">
          <div className="search-box">
            <Icon name="search" />
            <input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value)
                setSearchOpen(true)
              }}
              onFocus={() => setSearchOpen(true)}
              placeholder="Cerca un luogo…"
              aria-label="Cerca un luogo"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                aria-label="Cancella ricerca"
              >
                <Icon name="close" size={18} />
              </button>
            )}
          </div>
          <button
            className="icon-button glass"
            onClick={() => setAccount(true)}
            aria-label="Account"
          >
            <Icon name="user" />
          </button>
          <button
            className="icon-button glass"
            onClick={() => setNotice(true)}
            aria-label="Avvertenze"
          >
            <Icon name="info" />
          </button>
        </div>
        {searchOpen && (
          <div className="search-results">
            <p>Luoghi vicini</p>
            {[
              "Monte Cocuzzo, Mendicino",
              "Faggeta di Potame, Domanico",
              "Monte Scuro, Sila",
            ].map((r, i) => (
              <button
                key={r}
                onClick={() => {
                  setSearch(r)
                  setSearchOpen(false)
                }}
              >
                <Icon name="locate" />
                <span>
                  {r}
                  <small>{[3.2, 8.7, 24][i]} km da te</small>
                </span>
              </button>
            ))}
          </div>
        )}
        <div className="species-row">
          {species.map((s, i) => (
            <button
              key={s[0]}
              className={i === selectedSpecies ? "active" : ""}
              onClick={() => setSelectedSpecies(i)}
            >
              <strong>{s[0]}</strong>
              <small>{s[1]}</small>
            </button>
          ))}
        </div>
      </header>

      <div className="status-chips">
        {offline && (
          <button className="offline-chip" onClick={() => setOffline(false)}>
            Offline
          </button>
        )}
        {grid && (
          <span className="radius-chip">
            <Icon name="layers" size={16} /> Raggio 2,5 km
          </span>
        )}
      </div>

      <div className="float-controls">
        <button className="map-fab" aria-label="Centra su di me">
          <Icon name="locate" />
        </button>
        {grid && (
          <button
            className="map-fab remove"
            onClick={() => setGrid(false)}
            aria-label="Rimuovi griglia"
          >
            <Icon name="close" />
          </button>
        )}
      </div>

      {!detail && (
        <section className={`bottom-sheet ${sheet}`}>
          <button
            className="sheet-grab-area"
            onClick={() =>
              setSheet(sheet === "partial" ? "expanded" : "partial")
            }
            aria-label={
              sheet === "partial" ? "Espandi pannello" : "Riduci pannello"
            }
          >
            <span className="sheet-handle" />
            <Icon name="chevron" />
          </button>
          <div className="sheet-content">
            {banner && (
              <div className={`banner ${banner}`}>
                <Icon name={banner === "gps" ? "warning" : "info"} />
                <span>
                  {banner === "gps"
                    ? "Posizione GPS non disponibile."
                    : "Vegetazione non disponibile: il punteggio non la include."}
                </span>
                <button onClick={() => setBanner(null)}>
                  {banner === "gps" ? "Riprova" : "Chiudi"}
                </button>
              </div>
            )}
            {loading ? (
              <div className="loading-state">
                <span className="spinner" />
                <div>
                  <strong>
                    {loading === 1
                      ? "Scarico meteo e quote…"
                      : "Carico la vegetazione…"}
                  </strong>
                  <p>Puoi continuare a esplorare la mappa.</p>
                </div>
              </div>
            ) : (
              <>
                {!grid && (
                  <div className="empty-hint">
                    <span>🍄</span>
                    <p>
                      <strong>Dove cerchiamo?</strong> Calcola la probabilità
                      nelle vicinanze.
                    </p>
                  </div>
                )}
                <button
                  className="button primary calculate"
                  onClick={calculate}
                >
                  Calcola intorno a me
                </button>
                <button className="button secondary" onClick={calculate}>
                  Calcola sul centro della mappa
                </button>
              </>
            )}
            <PointSection
              state={point}
              onSave={() => setPoint("saved")}
              onArrive={() => setPoint("arrived")}
              onConfirm={setConfirm}
            />
            <div className="legend">
              <button onClick={() => setLegend(!legend)}>
                <span>
                  <strong>Legenda probabilità</strong>
                  <small>6 fasce · punteggio 0–100</small>
                </span>
                <Icon name="chevron" />
              </button>
              {legend && (
                <div className="legend-grid">
                  {bands.map((b) => (
                    <div key={b.key}>
                      <i style={{ background: b.color }} />
                      <span>
                        {b.label}
                        <small>{b.range}</small>
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <p className="tip">
              <Icon name="info" size={17} /> Tocca una cella per vedere i motivi
              del punteggio.
            </p>
            {sheet === "expanded" && (
              <div className="demo-states">
                <span>Anteprima stati</span>
                <button onClick={() => setOffline(!offline)}>Offline</button>
                <button onClick={() => setPoint("unavailable")}>
                  GPS assente
                </button>
                <button onClick={() => setBanner("gps")}>Errore GPS</button>
              </div>
            )}
          </div>
        </section>
      )}

      {detail && (
        <CellDetail
          speciesName={species[selectedSpecies][0]}
          onClose={() => setDetail(false)}
        />
      )}
      {account && (
        <AccountPanel
          onClose={() => setAccount(false)}
          dark={dark}
          setDark={setDark}
        />
      )}
      {notice && <Notice onClose={() => setNotice(false)} />}
      {confirm && (
        <div className="modal-layer align-bottom">
          <div className="confirm-sheet" role="dialog">
            <div className="sheet-handle" />
            <h2>
              {confirm === "delete"
                ? "Eliminare il punto?"
                : "Sostituire il punto?"}
            </h2>
            <p>
              {confirm === "delete"
                ? "Non potrai più usarlo per tornare al punto di partenza."
                : "Il punto attuale verrà sostituito con la tua posizione GPS."}
            </p>
            <button
              className={`button ${
                confirm === "delete" ? "danger" : "primary"
              }`}
              onClick={() => {
                setPoint(confirm === "delete" ? "none" : "saved")
                setConfirm(null)
              }}
            >
              {confirm === "delete" ? "Elimina punto" : "Sostituisci punto"}
            </button>
            <button
              className="button secondary"
              onClick={() => setConfirm(null)}
            >
              Annulla
            </button>
          </div>
        </div>
      )}
    </main>
  )
}
